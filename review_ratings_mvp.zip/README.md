# Projeto MVP - Travel Review Ratings
Este projeto consiste em um modelo de machine learning para classificação de avaliações de viagem com uma aplicação full stack simples.
